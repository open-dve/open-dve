odve-index-tools-2026.11.01: portable tools of the odve code index (Linux x86_64, CPython 3.12)

Contents
  VERSION, MANIFEST.sha256 (sha256sum -c MANIFEST.sha256)
  wheels/pyslang-12.1.0-cp311-abi3-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl
  wheels/nanobind_backend-1.0.0-cp312-cp312-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl
  wheels/pip-26.2.2-py3-none-any.whl
  tools/uctags-2026.10.08-linux-x86_64.release.tar.xz      Universal Ctags 2026.10.08, static build

Needs on the target: a CPython 3.12 (any patch level; python is not bundled)
with its venv module, glibc >= 2.27, bash, tar, xz. No pip, no network.

Install, from a clone of the repository that contains odve:
  odve/script/index/setup.sh --bundle <this tarball> [--python /path/to/python3.12]
  odve/script/index/odve_index.py build

setup.sh creates <root>/.odve-index/venv from the given python (without
ensurepip), installs pip and the wheels from this bundle into it, unpacks
ctags into <root>/.odve-index/tools, and reports what is active (--check).
